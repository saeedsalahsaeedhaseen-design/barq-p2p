package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.AppScreen
import com.example.model.TransferDirection
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LiveTransferScreen
import com.example.ui.screens.QrScannerScreen
import com.example.ui.screens.ReceiveFilesScreen
import com.example.ui.screens.SendFilesScreen
import com.example.ui.screens.WebRtcPeerJsPortalScreen
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.MidnightBg
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.P2PTransferViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                BarqP2PApp()
            }
        }
    }
}

@Composable
fun BarqP2PApp(
    viewModel: P2PTransferViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightBg),
        containerColor = MidnightBg,
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            NavigationBar(
                containerColor = MidnightSurface,
                tonalElevation = 8.dp
            ) {
                val navItems = listOf(
                    Triple(AppScreen.HOME, "الرئيسية", Icons.Filled.Home),
                    Triple(AppScreen.SEND, "إرسال", Icons.Filled.CloudUpload),
                    Triple(AppScreen.RECEIVE, "استلام", Icons.Filled.CloudDownload),
                    Triple(AppScreen.LIVE_TRANSFER, "النقل الحي", Icons.Filled.Speed),
                    Triple(AppScreen.WEBRTC_PORTAL, "PeerJS ويب", Icons.Filled.Language)
                )
                navItems.forEach { (screen, label, icon) ->
                    val selected = uiState.currentScreen == screen ||
                        (screen == AppScreen.RECEIVE && uiState.currentScreen == AppScreen.QR_SCANNER)
                    NavigationBarItem(
                        selected = selected,
                        onClick = { viewModel.navigateTo(screen) },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = label
                            )
                        },
                        label = {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelMedium
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ElectricCyan,
                            selectedTextColor = ElectricCyan,
                            indicatorColor = ElectricCyan.copy(alpha = 0.16f),
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("bottom_nav_${screen.name}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Optional Status Banner Toast
            AnimatedVisibility(
                visible = uiState.statusBannerMessage != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                uiState.statusBannerMessage?.let { msg ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0A2924))
                            .border(1.dp, NeonEmerald.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                            .clickable { viewModel.clearBannerMessage() }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = msg,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "إغلاق",
                                style = MaterialTheme.typography.labelMedium,
                                color = NeonEmerald
                            )
                        }
                    }
                }
            }

            Box(modifier = Modifier.weight(1f)) {
                when (uiState.currentScreen) {
                    AppScreen.HOME -> HomeScreen(
                        uiState = uiState,
                        onNavigate = { viewModel.navigateTo(it) },
                        onRefreshNetwork = { viewModel.refreshNetworkStatus() },
                        onShowHotspotGuide = { viewModel.toggleHotspotGuideSheet(it) },
                        onQuickStartDemo = {
                            viewModel.startLiveChunkedTransfer(TransferDirection.SENDING)
                        },
                        onExportApk = {
                            viewModel.exportSelfApkToDownloads()
                        }
                    )

                    AppScreen.SEND -> SendFilesScreen(
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.HOME) },
                        onPickFiles = { viewModel.addPickedUris(it) },
                        onAddSampleBundle = { viewModel.addRealSampleFilesBundle() },
                        onRemoveFile = { viewModel.removeFileItem(it) },
                        onRegenerateCode = { viewModel.regenerateConnectionCode() },
                        onSelectChunkSize = { viewModel.setChunkSize(it) },
                        onStartSending = {
                            viewModel.startLiveChunkedTransfer(TransferDirection.SENDING)
                        }
                    )

                    AppScreen.RECEIVE -> ReceiveFilesScreen(
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.HOME) },
                        onCodeChanged = { viewModel.updateEnteredReceiveCode(it) },
                        onConnectWithCode = { code ->
                            viewModel.connectAndReceiveFromInput(code)
                        },
                        onOpenQrScanner = { viewModel.navigateTo(AppScreen.QR_SCANNER) }
                    )

                    AppScreen.QR_SCANNER -> QrScannerScreen(
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.RECEIVE) },
                        onQrDetected = { qrPayload ->
                            viewModel.connectAndReceiveFromInput(qrPayload)
                        }
                    )

                    AppScreen.LIVE_TRANSFER -> LiveTransferScreen(
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.HOME) },
                        onTogglePauseResume = { viewModel.togglePauseResume() },
                        onRestartTransfer = {
                            viewModel.startLiveChunkedTransfer(uiState.transferDirection)
                        }
                    )

                    AppScreen.WEBRTC_PORTAL -> WebRtcPeerJsPortalScreen(
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.HOME) }
                    )
                }
            }
        }
    }
}
