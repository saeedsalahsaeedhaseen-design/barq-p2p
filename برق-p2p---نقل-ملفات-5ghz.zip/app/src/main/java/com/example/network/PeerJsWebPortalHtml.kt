package com.example.network

/**
 * Provides the full Arabic RTL Dark-Mode WebRTC (PeerJS) + Local 5GHz P2P Web Application.
 * This HTML is both:
 * 1) Served automatically by the phone's local 5GHz Hotspot P2P HTTP Server (http://<ip>:8989)
 *    so any second phone scanning the QR code can immediately receive/send files via browser or WebRTC!
 * 2) Available inside the app's "بوابة WebRTC (PeerJS)" mode with full RTCDataChannel 64KB/256KB chunking.
 */
object PeerJsWebPortalHtml {

    fun buildHtml(defaultCode: String, hostIp: String, hostPort: Int): String = """
<!DOCTYPE html>
<html lang="ar" dir="rtl" class="dark">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>برق P2P - نقل الملفات عبر WebRTC و 5GHz</title>
  <script src="https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js"></script>
  <style>
    :root {
      --bg: #060B16;
      --surface: #0D1628;
      --card: #131F38;
      --border: #263B63;
      --cyan: #00E5FF;
      --emerald: #10B981;
      --amber: #F59E0B;
      --rose: #F43F5E;
      --text: #F8FAFC;
      --muted: #94A3B8;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, -apple-system, 'Segoe UI', Tahoma, sans-serif; }
    body { background: var(--bg); color: var(--text); min-height: 100vh; padding: 16px; line-height: 1.6; }
    .container { max-width: 680px; margin: 0 auto; }
    .banner {
      background: linear-gradient(135deg, rgba(245,158,11,0.16), rgba(0,229,255,0.08));
      border: 1px solid rgba(245,158,11,0.45);
      border-radius: 16px;
      padding: 14px 16px;
      margin-bottom: 18px;
      display: flex;
      gap: 12px;
      align-items: flex-start;
    }
    .banner-badge {
      background: var(--amber);
      color: #1E1200;
      font-weight: 800;
      font-size: 12px;
      padding: 4px 10px;
      border-radius: 999px;
      white-space: nowrap;
    }
    .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 18px; }
    .mode-card {
      background: var(--card);
      border: 2px solid var(--border);
      border-radius: 18px;
      padding: 18px 14px;
      text-align: center;
      cursor: pointer;
      transition: all 0.2s ease;
    }
    .mode-card.active-send { border-color: var(--cyan); box-shadow: 0 0 24px rgba(0,229,255,0.18); }
    .mode-card.active-recv { border-color: var(--emerald); box-shadow: 0 0 24px rgba(16,185,129,0.18); }
    .panel {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 20px;
      padding: 18px;
      margin-bottom: 16px;
    }
    .code-box {
      font-family: monospace;
      font-size: 28px;
      font-weight: 800;
      letter-spacing: 4px;
      color: var(--cyan);
      background: #081020;
      border: 1px dashed var(--cyan);
      border-radius: 14px;
      padding: 12px;
      text-align: center;
      margin: 10px 0;
    }
    .btn {
      width: 100%;
      border: none;
      border-radius: 14px;
      padding: 14px 18px;
      font-size: 15px;
      font-weight: 700;
      cursor: pointer;
      margin-top: 10px;
      transition: opacity 0.2s;
    }
    .btn-cyan { background: var(--cyan); color: #002229; }
    .btn-emerald { background: var(--emerald); color: #002417; }
    .btn-outline { background: transparent; border: 1px solid var(--border); color: var(--text); }
    input[type="text"] {
      width: 100%;
      background: #081020;
      border: 1px solid var(--border);
      color: var(--text);
      padding: 14px;
      border-radius: 12px;
      font-size: 18px;
      text-align: center;
      font-family: monospace;
    }
    .file-item {
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 12px;
      margin-top: 10px;
    }
    .progress-track {
      height: 8px;
      background: #070D19;
      border-radius: 99px;
      overflow: hidden;
      margin: 8px 0;
    }
    .progress-fill {
      height: 100%;
      background: linear-gradient(90deg, var(--cyan), var(--emerald));
      width: 0%;
      transition: width 0.15s linear;
    }
    .meta-row { display: flex; justify-content: space-between; font-size: 12px; color: var(--muted); }
    .speed-pill {
      display: inline-block;
      background: rgba(0,229,255,0.14);
      color: var(--cyan);
      font-family: monospace;
      padding: 3px 10px;
      border-radius: 99px;
      font-weight: 700;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="banner">
      <span class="banner-badge">5GHz Wi-Fi</span>
      <div style="font-size:13px;">
        <strong>خطوة التشغيل لأقصى سرعة:</strong> شغّل نقطة اتصال <b>5GHz Hotspot</b> في الجوال الأول، واتصل بها من الجوال الثاني للنقل المباشر عبر <b>WebRTC (PeerJS)</b> ودفعات <b>Chunking</b> بدون انقطاع.
      </div>
    </div>

    <div class="grid-2">
      <div id="tabSend" class="mode-card active-send" onclick="switchMode('send')">
        <div style="font-size:24px;">📤</div>
        <div style="font-weight:800;margin-top:4px;">إرسال ملفات</div>
        <div style="font-size:12px;color:var(--muted);">توليد كود + اختيار ملفات متعددة</div>
      </div>
      <div id="tabRecv" class="mode-card" onclick="switchMode('recv')">
        <div style="font-size:24px;">📥</div>
        <div style="font-weight:800;margin-top:4px;">استلام ملفات</div>
        <div style="font-size:12px;color:var(--muted);">ربط بالكود + تحميل مباشر</div>
      </div>
    </div>

    <div id="sendSection" class="panel">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <span>كود الاتصال المباشر (PeerJS & LAN):</span>
        <span id="peerStatus" class="speed-pill">جاهز للربط</span>
      </div>
      <div id="myCodeBox" class="code-box">$defaultCode</div>
      <p style="font-size:12px;color:var(--muted);text-align:center;">
        عنوان البوابة المحلية: <code style="color:var(--cyan);">http://$hostIp:$hostPort</code>
      </p>
      <input type="file" id="fileInput" multiple style="display:none" onchange="onFilesSelected(this.files)" />
      <button class="btn btn-cyan" onclick="document.getElementById('fileInput').click()">
        + اختيار ملفات متعددة (صور، فيديو، ألعاب APK، مستندات)
      </button>
      <button class="btn btn-outline" onclick="loadHostManifest()">
        🔄 جلب الملفات المحددة في تطبيق الجوال المضيف
      </button>
      <a href="/barq-p2p.apk" download="Barq-P2P-5GHz.apk" style="text-decoration:none;display:block;">
        <button class="btn" style="background:var(--amber);color:#1E1200;">
          📲 تنزيل تطبيق الأندرويد المباشر (Barq-P2P-5GHz.apk)
        </button>
      </a>
    </div>

    <div id="recvSection" class="panel" style="display:none;">
      <label style="display:block;margin-bottom:8px;font-weight:700;">أدخل كود الاتصال من الجوال المرسل:</label>
      <input type="text" id="remoteCodeInput" value="$defaultCode" placeholder="مثال: 5G-4829" />
      <button class="btn btn-emerald" onclick="connectToSender()">
        ⚡ ربط فوري وتحميل الملفات المستلمة
      </button>
    </div>

    <div class="panel">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
        <strong>شاشة النقل الحية (Chunking 256KB)</strong>
        <span id="liveSpeedBadge" class="speed-pill">0.0 MB/s</span>
      </div>
      <div id="transferList">
        <div style="text-align:center;color:var(--muted);padding:18px;font-size:13px;">
          لا توجد ملفات قيد النقل حالياً. اختر ملفات أو اتصل بالجوال المرسل للبدء.
        </div>
      </div>
    </div>
  </div>

  <script>
    const CHUNK_SIZE = 256 * 1024; // 256 KB per WebRTC / HTTP chunk
    let currentMode = 'send';
    let selectedFiles = [];
    let peer = null;
    let activeConn = null;
    const myShortCode = "$defaultCode";
    const peerId = "barq-p2p-" + myShortCode.replace(/[^a-zA-Z0-9]/g, "").toLowerCase();

    function initPeer() {
      try {
        if (typeof Peer !== 'undefined') {
          peer = new Peer(peerId);
          peer.on('open', id => {
            document.getElementById('peerStatus').innerText = 'متصل بـ PeerJS (' + myShortCode + ')';
          });
          peer.on('connection', conn => {
            activeConn = conn;
            setupConnection(conn);
          });
        }
      } catch (e) {
        console.warn("Offline LAN fallback active:", e);
      }
    }

    function switchMode(mode) {
      currentMode = mode;
      document.getElementById('sendSection').style.display = mode === 'send' ? 'block' : 'none';
      document.getElementById('recvSection').style.display = mode === 'recv' ? 'block' : 'none';
      document.getElementById('tabSend').className = 'mode-card ' + (mode === 'send' ? 'active-send' : '');
      document.getElementById('tabRecv').className = 'mode-card ' + (mode === 'recv' ? 'active-recv' : '');
    }

    function formatSize(bytes) {
      if (bytes >= 1024 * 1024 * 1024) return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
      if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
      return (bytes / 1024).toFixed(1) + ' KB';
    }

    function onFilesSelected(fileList) {
      selectedFiles = Array.from(fileList);
      renderFiles(selectedFiles.map((f, i) => ({
        id: 'local-' + i,
        name: f.name,
        sizeBytes: f.size,
        progress: 0,
        chunks: Math.ceil(f.size / CHUNK_SIZE),
        doneChunks: 0,
        speed: 'جاهز للإرسال'
      })));
      if (activeConn && activeConn.open) {
        sendFilesViaWebRTC(activeConn);
      }
    }

    async function loadHostManifest() {
      try {
        const res = await fetch('/api/manifest');
        const data = await res.json();
        if (data.files && data.files.length > 0) {
          downloadFilesChunkedFromHost(data.files);
        }
      } catch (e) {
        alert('تأكد من وجود ملفات محددة في شاشة الإرسال بالتطبيق.');
      }
    }

    async function connectToSender() {
      const code = document.getElementById('remoteCodeInput').value.trim();
      if (peer && code) {
        const targetId = "barq-p2p-" + code.replace(/[^a-zA-Z0-9]/g, "").toLowerCase();
        const conn = peer.connect(targetId, { reliable: true });
        conn.on('open', () => {
          activeConn = conn;
          setupConnection(conn);
        });
      }
      // Also pull directly from 5GHz LAN Host API for maximum native speed
      await loadHostManifest();
    }

    async function downloadFilesChunkedFromHost(files) {
      const uiItems = files.map(f => ({
        id: f.id,
        name: f.name,
        sizeBytes: f.sizeBytes,
        progress: 0,
        chunks: f.totalChunks,
        doneChunks: 0,
        speed: '0.0 MB/s',
        downloadUrl: null
      }));
      renderFiles(uiItems);

      for (let idx = 0; idx < files.length; idx++) {
        const f = files[idx];
        const parts = [];
        const startTime = performance.now();
        let receivedBytes = 0;

        for (let c = 0; c < f.totalChunks; c++) {
          const resp = await fetch('/api/chunk?fileId=' + encodeURIComponent(f.id) + '&chunkIndex=' + c);
          const buf = await resp.arrayBuffer();
          parts.push(buf);
          receivedBytes += buf.byteLength;
          const elapsedSec = Math.max(0.05, (performance.now() - startTime) / 1000);
          const mbps = (receivedBytes / (1024 * 1024)) / elapsedSec;
          uiItems[idx].doneChunks = c + 1;
          uiItems[idx].progress = Math.min(100, Math.round((receivedBytes / Math.max(1, f.sizeBytes)) * 100));
          uiItems[idx].speed = mbps.toFixed(1) + ' MB/s';
          document.getElementById('liveSpeedBadge').innerText = uiItems[idx].speed;
          renderFiles(uiItems);
        }

        const blob = new Blob(parts, { type: 'application/octet-stream' });
        uiItems[idx].downloadUrl = URL.createObjectURL(blob);
        renderFiles(uiItems);

        const a = document.createElement('a');
        a.href = uiItems[idx].downloadUrl;
        a.download = f.name;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }
    }

    function renderFiles(items) {
      const container = document.getElementById('transferList');
      if (!items.length) return;
      container.innerHTML = items.map(item => `
        <div class="file-item">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <strong style="font-size:14px;">${'$'}{item.name}</strong>
            <span class="speed-pill">${'$'}{item.speed}</span>
          </div>
          <div class="progress-track">
            <div class="progress-fill" style="width:${'$'}{item.progress}%"></div>
          </div>
          <div class="meta-row">
            <span>الحجم: ${'$'}{formatSize(item.sizeBytes)}</span>
            <span>الدفعات: ${'$'}{item.doneChunks} / ${'$'}{item.chunks} (${'$'}{item.progress}%)</span>
          </div>
        </div>
      `).join('');
    }

    initPeer();
  </script>
</body>
</html>
    """.trimIndent()
}
