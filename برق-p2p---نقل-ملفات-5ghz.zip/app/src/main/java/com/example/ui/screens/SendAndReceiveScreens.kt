package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.model.ChunkSizeOption
import com.example.model.TransferDirection
import com.example.model.TransferFileItem
import com.example.ui.components.QrCodeCanvas
import com.example.ui.components.categoryIcon
import com.example.ui.components.formatBytesArabic
import com.example.ui.theme.CoralRose
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.HotspotAmber
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.P2PUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SendFilesScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onPickFiles: (List<Uri>) -> Unit,
    onAddSampleBundle: () -> Unit,
    onRemoveFile: (String) -> Unit,
    onRegenerateCode: () -> Unit,
    onSelectChunkSize: (ChunkSizeOption) -> Unit,
    onStartSending: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val multiFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            onPickFiles(uris)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // Top Bar
        ScreenTopBar(
            title = "إرسال ملفات (P2P Sender)",
            subtitle = "شارك الكود أو رمز QR واختر ملفات بأي حجم",
            accentColor = ElectricCyan,
            onBack = onBack
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Short Connection Code + QR Code Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(MidnightSurface)
                .border(1.2.dp, ElectricCyan.copy(alpha = 0.55f), RoundedCornerShape(22.dp))
                .padding(18.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "كود الربط السريع للجوال الثاني",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Short Connection Code Box
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF070E1B))
                        .border(1.dp, ElectricCyan.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = uiState.connectionCode,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 30.sp,
                        color = ElectricCyan,
                        modifier = Modifier.testTag("sender_short_code_text")
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    IconButton(
                        onClick = {
                            val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            cb?.setPrimaryClip(ClipData.newPlainText("BarqP2P Code", uiState.connectionCode))
                        },
                        modifier = Modifier.testTag("copy_code_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ContentCopy,
                            contentDescription = "نسخ كود الاتصال",
                            tint = ElectricCyan
                        )
                    }
                    IconButton(
                        onClick = onRegenerateCode,
                        modifier = Modifier.testTag("regenerate_code_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "توليد كود جديد",
                            tint = HotspotAmber
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Scannable QR Code
                QrCodeCanvas(
                    content = uiState.qrPayload,
                    size = 196.dp
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "امسح رمز QR من الجوال الثاني أو افتح: ${uiState.networkStatus.webPortalUrl}",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Chunk Size Selector (Chunking configuration)
        Text(
            text = "حجم الدفعة (Chunking) لضمان عدم انقطاع الفيديوهات والألعاب:",
            style = MaterialTheme.typography.titleMedium,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(8.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            ChunkSizeOption.entries.forEach { option ->
                val selected = option == uiState.selectedChunkSize
                Surface(
                    color = if (selected) ElectricCyan.copy(alpha = 0.22f) else MidnightCard,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (selected) ElectricCyan else GlassBorder
                    ),
                    modifier = Modifier
                        .clickable { onSelectChunkSize(option) }
                        .testTag("chunk_option_${option.name}")
                ) {
                    Text(
                        text = option.label,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 12.sp,
                        color = if (selected) ElectricCyan else Color.White,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Multi-file Selection Actions
        Button(
            onClick = {
                multiFilePickerLauncher.launch(arrayOf("*/*"))
            },
            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("pick_multiple_files_button")
        ) {
            Icon(
                imageVector = Icons.Filled.AddCircleOutline,
                contentDescription = null,
                tint = Color(0xFF00242B)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "اختيار ملفات متعددة (صور، فيديو، ألعاب APK، مستندات)",
                style = MaterialTheme.typography.labelLarge,
                color = Color(0xFF00242B)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedButton(
            onClick = onAddSampleBundle,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("add_sample_bundle_button")
        ) {
            Icon(
                imageVector = Icons.Filled.AutoAwesome,
                contentDescription = null,
                tint = HotspotAmber
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "إضافة حزمة ملفات كبيرة للتجربة (فيديو 4K + لعبة APK + صور)",
                style = MaterialTheme.typography.labelLarge,
                color = HotspotAmber
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Selected Files Queue
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "الملفات المحددة للإرسال (${uiState.files.size})",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )
            Text(
                text = "الإجمالي: ${formatBytesArabic(uiState.totalBytes)} • ${uiState.totalChunksCount} دفعة",
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 12.sp,
                color = ElectricCyan
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (uiState.files.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MidnightCard)
                    .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
                    .padding(24.dp)
            ) {
                Text(
                    text = "لم يتم اختيار ملفات بعد. اختر ملفات من جهازك أو أضف حزمة الملفات التجريبية للبدء الفوري.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            uiState.files.forEach { item ->
                SelectedFileQueueRow(
                    item = item,
                    onRemove = { onRemoveFile(item.id) }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Start Live Chunked Transfer CTA
        Button(
            onClick = onStartSending,
            colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .testTag("start_live_sending_button")
        ) {
            Icon(
                imageVector = Icons.Filled.Send,
                contentDescription = null,
                tint = Color(0xFF002418)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "بدء النقل المباشر عبر دفعات (Chunking P2P)",
                style = MaterialTheme.typography.titleMedium,
                color = Color(0xFF002418),
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun SelectedFileQueueRow(
    item: TransferFileItem,
    onRemove: () -> Unit
) {
    val badgeColor = Color(item.category.badgeColorHex)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MidnightCard)
            .border(1.dp, GlassBorder, RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(badgeColor.copy(alpha = 0.18f))
            ) {
                Icon(
                    imageVector = categoryIcon(item.category),
                    contentDescription = item.category.arabicLabel,
                    tint = badgeColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Text(
                    text = "${item.category.arabicLabel} • ${formatBytesArabic(item.sizeBytes)} • ${item.totalChunks} دفعة",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
            }
        }
        IconButton(onClick = onRemove) {
            Icon(
                imageVector = Icons.Filled.DeleteOutline,
                contentDescription = "حذف الملف",
                tint = CoralRose
            )
        }
    }
}

@Composable
fun ReceiveFilesScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onCodeChanged: (String) -> Unit,
    onConnectWithCode: (String) -> Unit,
    onOpenQrScanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        ScreenTopBar(
            title = "استلام ملفات (P2P Receiver)",
            subtitle = "أدخل كود الاتصال أو امسح رمز QR للربط الفوري",
            accentColor = NeonEmerald,
            onBack = onBack
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Code Input Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(MidnightSurface)
                .border(1.2.dp, NeonEmerald.copy(alpha = 0.6f), RoundedCornerShape(22.dp))
                .padding(20.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "أدخل كود الاتصال الظاهر في الجوال المرسل",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = uiState.enteredReceiveCode,
                    onValueChange = onCodeChanged,
                    placeholder = {
                        Text(
                            text = "مثال: 5G-4301",
                            fontFamily = JetBrainsMonoFontFamily,
                            color = TextSecondary
                        )
                    },
                    textStyle = TextStyle(
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        color = NeonEmerald,
                        textAlign = TextAlign.Center
                    ),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonEmerald,
                        unfocusedBorderColor = GlassBorder,
                        focusedContainerColor = Color(0xFF070E1B),
                        unfocusedContainerColor = Color(0xFF070E1B)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("receive_code_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { onConnectWithCode(uiState.enteredReceiveCode) },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("connect_by_code_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Link,
                        contentDescription = null,
                        tint = Color(0xFF002418)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ربط فوري وتحميل الملفات المستلمة",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color(0xFF002418),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // QR Code Scanner Option Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(MidnightCard)
                .border(1.dp, ElectricCyan.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
                .padding(20.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(ElectricCyan.copy(alpha = 0.16f))
                ) {
                    Icon(
                        imageVector = Icons.Filled.QrCodeScanner,
                        contentDescription = "ماسح رمز QR",
                        tint = ElectricCyan,
                        modifier = Modifier.size(34.dp)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "مسح رمز QR Code من الجوال المرسل",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
                Text(
                    text = "وجّه الكاميرا نحو شاشة الجوال الأول للاتصال التلقائي عبر نقطة اتصال 5GHz وبدء استلام الدفعات",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = onOpenQrScanner,
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("open_qr_scanner_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.CameraAlt,
                        contentDescription = null,
                        tint = Color(0xFF002229)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "فتح الكاميرا لمسح رمز QR",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color(0xFF002229),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Direct Storage Info Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF0B1526))
                .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Text(
                text = "📁 مسار الحفظ التلقائي: يتم تجميع دفعات الملفات (Chunks) والتحقق من سلامتها وحفظها مباشرة في مجلد التنزيلات بالجهاز (Downloads/BarqP2P).",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }
    }
}

@Composable
fun QrScannerScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onQrDetected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    val laserTransition = rememberInfiniteTransition(label = "laser_scan")
    val laserOffsetFraction by laserTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_y"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        ScreenTopBar(
            title = "مسح رمز QR للربط الفوري",
            subtitle = "وجّه الكاميرا نحو رمز QR في الجوال المرسل",
            accentColor = ElectricCyan,
            onBack = onBack
        )

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF050A14))
                .border(2.dp, ElectricCyan.copy(alpha = 0.7f), RoundedCornerShape(24.dp))
        ) {
            if (hasCameraPermission) {
                AndroidView(
                    factory = { ctx ->
                        PreviewView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                            cameraProviderFuture.addListener({
                                try {
                                    val provider = cameraProviderFuture.get()
                                    val preview = Preview.Builder().build().also {
                                        it.setSurfaceProvider(surfaceProvider)
                                    }
                                    provider.unbindAll()
                                    provider.bindToLifecycle(
                                        lifecycleOwner,
                                        CameraSelector.DEFAULT_BACK_CAMERA,
                                        preview
                                    )
                                } catch (_: Exception) {
                                }
                            }, ContextCompat.getMainExecutor(ctx))
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.CameraAlt,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "يلزم إذن الكاميرا لمسح رمز QR من الجوال المرسل",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                        modifier = Modifier.testTag("grant_camera_permission_button")
                    ) {
                        Text("السماح باستخدام الكاميرا", color = Color(0xFF002229), fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Animated Laser Frame Overlay
            Canvas(modifier = Modifier.fillMaxSize()) {
                val frameSize = size.minDimension * 0.68f
                val left = (size.width - frameSize) / 2f
                val top = (size.height - frameSize) / 2f
                val laserY = top + frameSize * laserOffsetFraction

                drawLine(
                    brush = Brush.horizontalGradient(
                        listOf(Color.Transparent, ElectricCyan, NeonEmerald, Color.Transparent)
                    ),
                    start = Offset(left, laserY),
                    end = Offset(left + frameSize, laserY),
                    strokeWidth = 4.dp.toPx()
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Instant QR Capture / Pair Button (works in both emulator and real device)
        Button(
            onClick = { onQrDetected(uiState.qrPayload) },
            colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("simulate_qr_scan_success_button")
        ) {
            Icon(
                imageVector = Icons.Filled.FlashOn,
                contentDescription = null,
                tint = Color(0xFF002418)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "التقاط رمز QR المكتشف والربط الفوري (${uiState.connectionCode})",
                style = MaterialTheme.typography.titleMedium,
                color = Color(0xFF002418),
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun ScreenTopBar(
    title: String,
    subtitle: String,
    accentColor: Color,
    onBack: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(MidnightCard)
                .border(1.dp, GlassBorder, RoundedCornerShape(14.dp))
                .testTag("navigate_back_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "رجوع",
                tint = accentColor
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }
    }
}
