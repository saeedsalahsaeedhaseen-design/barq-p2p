package com.example.model

import android.net.Uri
import java.io.File
import java.util.Locale

enum class FileCategory(
    val arabicLabel: String,
    val badgeColorHex: Long
) {
    VIDEO("فيديو فائق الدقة", 0xFFF43F5E),
    IMAGE("صورة / معرض", 0xFF00E5FF),
    GAME_APK("لعبة / تطبيق APK", 0xFF10B981),
    ARCHIVE("ملف مضغوط", 0xFFF59E0B),
    DOCUMENT("مستند / ملف", 0xFF8B5CF6);

    companion object {
        fun fromFileName(name: String, mimeType: String? = null): FileCategory {
            val lower = name.lowercase(Locale.ROOT)
            return when {
                lower.endsWith(".apk") || lower.endsWith(".xapk") || lower.endsWith(".obb") -> GAME_APK
                lower.endsWith(".mp4") || lower.endsWith(".mkv") || lower.endsWith(".mov") ||
                    lower.endsWith(".avi") || lower.endsWith(".webm") || mimeType?.startsWith("video/") == true -> VIDEO
                lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") ||
                    lower.endsWith(".webp") || lower.endsWith(".heic") || mimeType?.startsWith("image/") == true -> IMAGE
                lower.endsWith(".zip") || lower.endsWith(".rar") || lower.endsWith(".7z") ||
                    lower.endsWith(".tar") || lower.endsWith(".gz") -> ARCHIVE
                else -> DOCUMENT
            }
        }
    }
}

enum class TransferDirection(val arabicTitle: String) {
    SENDING("جاري الإرسال المباشر (P2P)"),
    RECEIVING("جاري الاستلام والتحميل (P2P)")
}

enum class FileTransferStatus(val arabicLabel: String) {
    QUEUED("في قائمة الانتظار"),
    TRANSFERRING("يُنقل الآن عبر دفعات (Chunks)"),
    PAUSED("متوقف مؤقتاً"),
    COMPLETED("اكتمل النقل بنجاح"),
    FAILED("فشل النقل")
}

enum class ChunkSizeOption(val bytes: Int, val label: String, val description: String) {
    CHUNK_256KB(256 * 1024, "256 KB", "متوازن للشبكات المتوسطة"),
    CHUNK_512KB(512 * 1024, "512 KB", "مثالي للصور والمستندات"),
    CHUNK_1MB(1024 * 1024, "1 MB (موصى به)", "سرعة قصوى لنقطة اتصال 5GHz"),
    CHUNK_2MB(2 * 1024 * 1024, "2 MB (توربو)", "للألعاب الضخمة وفيديوهات 4K")
}

data class TransferFileItem(
    val id: String,
    val name: String,
    val sizeBytes: Long,
    val category: FileCategory,
    val uri: Uri? = null,
    val localFile: File? = null,
    val totalChunks: Int,
    val completedChunks: Int = 0,
    val transferredBytes: Long = 0L,
    val currentSpeedMbps: Double = 0.0, // MB/s
    val status: FileTransferStatus = FileTransferStatus.QUEUED,
    val savedPath: String? = null,
    val checksumPreview: String = ""
) {
    val progressFraction: Float
        get() = if (sizeBytes <= 0L) 1f else (transferredBytes.toFloat() / sizeBytes.toFloat()).coerceIn(0f, 1f)

    val progressPercent: Int
        get() = (progressFraction * 100f).toInt().coerceIn(0, 100)
}

data class HotspotNetworkStatus(
    val localIp: String = "192.168.43.1",
    val port: Int = 8989,
    val is5GHzBand: Boolean = true,
    val frequencyMHz: Int = 5180,
    val linkSpeedMbps: Int = 866,
    val ssidOrInterface: String = "Hotspot-5GHz (wlan0)",
    val isServerRunning: Boolean = false
) {
    val webPortalUrl: String
        get() = "http://$localIp:$port"
}

enum class AppScreen {
    HOME,
    SEND,
    RECEIVE,
    QR_SCANNER,
    LIVE_TRANSFER,
    WEBRTC_PORTAL
}
